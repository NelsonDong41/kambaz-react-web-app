import { Button, InputGroup, ListGroup } from "react-bootstrap";
import { IoIosSearch } from "react-icons/io";
import { Form, Row, Col } from "react-bootstrap";
import { BsGripVertical, BsPlus } from "react-icons/bs";
import LessonControlButtons from "../Modules/LessonControlButtons";
import { LuNotebookPen } from "react-icons/lu";
import { IoEllipsisVertical } from "react-icons/io5";
import { useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router";
import { deleteAssignment } from "./reducer";
import { FaTrash } from "react-icons/fa";

export default function Assignments() {
  const dispatch = useDispatch()
  const { cid } = useParams();
  const { currentUser } = useSelector((state: any) => state.accountReducer);
  const { assignments } = useSelector((state: any) => state.assignmentReducer);
  const isFaculty = currentUser.role === "FACULTY";

  return (
    <div id="wd-assignments">
      <div className="d-flex col justify-content-between align-items-center mb-5">
        <Row>
          <Form.Group as={Col}>
            <InputGroup>
              <InputGroup.Text>
                <IoIosSearch />
              </InputGroup.Text>
              <Form.Control type="text" placeholder="Search here.." />
            </InputGroup>
          </Form.Group>
        </Row>
        <div>
          <Button
            variant="secondary"
            size="lg"
            className="me-1 align-self-end"
            id="wd-view-progress"
          >
            + Group
          </Button>
          <Button
            variant="danger"
            size="lg"
            className="me-1 justify-content-end"
            id="wd-view-progress"
          >
            <Link className="text-decoration-none text-white" to={`/Kambaz/Courses/${cid}/Assignments/new`}>
              + Assignment
            </Link>
          </Button>
        </div>
      </div>
      <ListGroup className="rounded-0" id="wd-modules">
        <ListGroup.Item className="wd-module p-0 mb-5 fs-5 border-gray">
          <div className="wd-title p-4 ps-2 bg-secondary">
            <BsGripVertical className="fs-3 mx-2" />
            ASSIGNMENTS
            <div className="float-end">
              <span className="me-1 p-2 position-relative border rounded-5 border-black">
                40% of Total
              </span>
              <BsPlus />
              <IoEllipsisVertical className="fs-4" />
            </div>
          </div>
          <ListGroup className="wd-lessons rounded-0">
            {assignments
              .filter((assignment: any) => assignment.course === cid)
              .map((assignment: any) => (
                <ListGroup.Item
                  key={assignment._id}
                  className="wd-lesson p-3 ps-1 d-flex flex-row align-items-center"
                >
                  <BsGripVertical className="me-2 fs-3 flex-shrink-0 mx-2" />
                  <LuNotebookPen className="flex-shrink-0 mx-2" />
                  <span className="d-flex flex-column flex-grow-1 flex-shrink-1 mx-2">
                    {isFaculty ? (
                      <a
                        href={`#/Kambaz/Courses/${cid}/Assignments/${assignment._id}`}
                        className="wd-assignment-link  text-decoration-none text-black"
                      >
                        <strong>{assignment.title}</strong>
                      </a>
                    ) : (
                      <strong>{assignment.title}</strong>
                    )}
                    <div>
                      <span>Multiple Modules | </span>
                      <strong>Not available until | </strong>
                      <span>{assignment.from} | </span>
                      <strong>Due </strong>
                      <span>{assignment.due} | </span>
                      <span>{assignment.points} pts</span>
                    </div>
                  </span>
                  <FaTrash
                    className="text-danger me-2 mb-1"
                    cursor={"pointer"}
                    onClick={() => dispatch(deleteAssignment(assignment._id))}
                  />
                  <LessonControlButtons />
                </ListGroup.Item>
              ))}
          </ListGroup>
        </ListGroup.Item>
      </ListGroup>
    </div>
  );
}
